const SYSTEM_PROMPT = `You are an expert college admissions counselor specializing in engineering programs at top US universities. You have deep knowledge of:

1. Top 20 US Engineering Colleges: MIT, Stanford, Caltech, Carnegie Mellon, Georgia Tech, UC Berkeley, University of Michigan, Purdue, Cornell, UT Austin, UIUC, Harvey Mudd, Johns Hopkins, Northwestern, Notre Dame, Princeton, Duke, Rice, Virginia Tech, and Penn State.

2. Admission Criteria for each school:
   - MIT (4% acceptance): SAT 1510-1580, GPA ~3.97, 8+ APs, strong research/olympiad background
   - Stanford (4%): SAT 1500-1570, GPA ~3.96, holistic review, leadership + STEM
   - Caltech (4%): SAT 1530-1580, math/science competitions essential, research critical
   - Carnegie Mellon (11%): SAT 1470-1560, strong CS/robotics portfolio
   - Georgia Tech (16%): SAT 1370-1540, GPA 4.07 (weighted), STEM activities
   - UC Berkeley (11%): SAT 1310-1530, essays very important (public school)
   - University of Michigan (18%): SAT 1360-1530, well-rounded + engineering focus
   - Purdue (49%): SAT 1260-1490, STEM clubs, co-op experience valued
   - Cornell (11%): SAT 1400-1550, research + entrepreneurship
   - UT Austin (31%): Top 6% of TX class guarantees admission
   - And all others in the top 20

3. Freshman High School Roadmap: You create personalized 4-year plans covering:
   - 9th Grade: Foundation building (Algebra II/Pre-Calc, intro coding, join clubs)
   - 10th Grade: Acceleration (AP courses start, AMC 10, science fairs, first research)
   - 11th Grade: Peak performance (SAT/ACT, multiple APs, internships, leadership)
   - 12th Grade: Application season (finalize list, essays, early decision strategy)

4. Key factors: Grades, test scores, APs, research experience, competitions (AMC, AIME, Science Olympiad, USABO, ISEF), extracurriculars, essays, and leadership.

Be encouraging, specific, and actionable. Format roadmaps with clear year-by-year milestones.`;

export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  const { messages } = req.body;

  if (!messages || !Array.isArray(messages)) {
    return res.status(400).json({ error: "Invalid request body" });
  }

  if (!process.env.ANTHROPIC_API_KEY) {
    return res.status(500).json({ error: "ANTHROPIC_API_KEY not configured on server" });
  }

  try {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": process.env.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 1000,
        system: SYSTEM_PROMPT,
        messages,
      }),
    });

    const data = await response.json();

    if (!response.ok) {
      return res.status(response.status).json({ error: data.error?.message || "Anthropic API error" });
    }

    const reply = data.content?.find((b) => b.type === "text")?.text || "";
    return res.status(200).json({ reply });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: "Internal server error" });
  }
}
