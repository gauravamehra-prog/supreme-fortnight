import { useState, useRef, useEffect } from "react";
import Head from "next/head";

const COLLEGES = [
  { rank: 1, name: "MIT", location: "Cambridge, MA", acceptRate: "4%", satRange: "1510–1580", gpaAvg: "3.97", apCourses: "8+", researchExp: "Strongly preferred", extracurriculars: "STEM competitions, research, coding", essays: "Highly weighted", legacy: "Minimal impact", tags: ["🔬 Research", "🏆 Olympiad"] },
  { rank: 2, name: "Stanford", location: "Stanford, CA", acceptRate: "4%", satRange: "1500–1570", gpaAvg: "3.96", apCourses: "8+", researchExp: "Strongly preferred", extracurriculars: "Leadership, entrepreneurship, STEM", essays: "Critical", legacy: "Moderate impact", tags: ["🚀 Innovation", "🎭 Holistic"] },
  { rank: 3, name: "Caltech", location: "Pasadena, CA", acceptRate: "4%", satRange: "1530–1580", gpaAvg: "3.97", apCourses: "8+", researchExp: "Essential", extracurriculars: "Math/science competitions", essays: "Highly weighted", legacy: "Minimal impact", tags: ["🔬 Research", "🧮 Math"] },
  { rank: 4, name: "Carnegie Mellon", location: "Pittsburgh, PA", acceptRate: "11%", satRange: "1470–1560", gpaAvg: "3.90", apCourses: "6+", researchExp: "Preferred", extracurriculars: "CS projects, robotics", essays: "Very important", legacy: "Low impact", tags: ["💻 CS", "🤖 Robotics"] },
  { rank: 5, name: "Georgia Tech", location: "Atlanta, GA", acceptRate: "16%", satRange: "1370–1540", gpaAvg: "4.07", apCourses: "5+", researchExp: "Helpful", extracurriculars: "STEM clubs, internships", essays: "Important", legacy: "Low impact", tags: ["⚙️ Engineering", "💼 Co-op"] },
  { rank: 6, name: "UC Berkeley", location: "Berkeley, CA", acceptRate: "11%", satRange: "1310–1530", gpaAvg: "3.89", apCourses: "7+", researchExp: "Preferred", extracurriculars: "Research, leadership", essays: "Very important", legacy: "No impact", tags: ["🔬 Research", "🌍 Public"] },
  { rank: 7, name: "University of Michigan", location: "Ann Arbor, MI", acceptRate: "18%", satRange: "1360–1530", gpaAvg: "3.90", apCourses: "5+", researchExp: "Helpful", extracurriculars: "Engineering clubs, sports", essays: "Important", legacy: "Some impact", tags: ["⚙️ Engineering", "🏫 Public"] },
  { rank: 8, name: "Purdue", location: "West Lafayette, IN", acceptRate: "49%", satRange: "1260–1490", gpaAvg: "3.78", apCourses: "4+", researchExp: "Helpful", extracurriculars: "STEM clubs, co-ops", essays: "Moderate", legacy: "Low impact", tags: ["✈️ Aerospace", "💼 Co-op"] },
  { rank: 9, name: "Cornell", location: "Ithaca, NY", acceptRate: "11%", satRange: "1400–1550", gpaAvg: "3.90", apCourses: "6+", researchExp: "Preferred", extracurriculars: "Research, entrepreneurship", essays: "Very important", legacy: "Moderate impact", tags: ["🔬 Research", "🌱 Diverse"] },
  { rank: 10, name: "UT Austin", location: "Austin, TX", acceptRate: "31%", satRange: "1250–1480", gpaAvg: "3.83", apCourses: "4+", researchExp: "Helpful", extracurriculars: "STEM clubs, internships", essays: "Important", legacy: "Low impact", tags: ["🤠 Texas", "🏫 Public"] },
  { rank: 11, name: "UIUC", location: "Champaign, IL", acceptRate: "45%", satRange: "1310–1510", gpaAvg: "3.83", apCourses: "5+", researchExp: "Helpful", extracurriculars: "Hackathons, clubs", essays: "Moderate", legacy: "Low impact", tags: ["💻 CS", "🏫 Public"] },
  { rank: 12, name: "Harvey Mudd", location: "Claremont, CA", acceptRate: "13%", satRange: "1480–1570", gpaAvg: "4.17", apCourses: "7+", researchExp: "Preferred", extracurriculars: "Math/CS competitions", essays: "Highly weighted", legacy: "Minimal impact", tags: ["🧮 Math", "🔬 STEM"] },
  { rank: 13, name: "Johns Hopkins", location: "Baltimore, MD", acceptRate: "7%", satRange: "1500–1570", gpaAvg: "3.90", apCourses: "7+", researchExp: "Essential", extracurriculars: "Research, biomedical", essays: "Critical", legacy: "Some impact", tags: ["🏥 Biomedical", "🔬 Research"] },
  { rank: 14, name: "Northwestern", location: "Evanston, IL", acceptRate: "7%", satRange: "1490–1570", gpaAvg: "4.10", apCourses: "7+", researchExp: "Preferred", extracurriculars: "Leadership, STEM", essays: "Very important", legacy: "Some impact", tags: ["🌟 Holistic", "🔬 Research"] },
  { rank: 15, name: "Notre Dame", location: "Notre Dame, IN", acceptRate: "13%", satRange: "1400–1540", gpaAvg: "3.90", apCourses: "6+", researchExp: "Preferred", extracurriculars: "Service, leadership", essays: "Very important", legacy: "Significant impact", tags: ["⛪ Values", "🏅 Leadership"] },
  { rank: 16, name: "Princeton", location: "Princeton, NJ", acceptRate: "4%", satRange: "1500–1570", gpaAvg: "3.92", apCourses: "8+", researchExp: "Strongly preferred", extracurriculars: "Diverse, leadership", essays: "Critical", legacy: "Moderate impact", tags: ["👑 Ivy", "🔬 Research"] },
  { rank: 17, name: "Duke", location: "Durham, NC", acceptRate: "6%", satRange: "1490–1570", gpaAvg: "3.95", apCourses: "7+", researchExp: "Preferred", extracurriculars: "Research, sports", essays: "Very important", legacy: "Moderate impact", tags: ["🏀 Sports", "🔬 Research"] },
  { rank: 18, name: "Rice", location: "Houston, TX", acceptRate: "9%", satRange: "1480–1570", gpaAvg: "4.12", apCourses: "7+", researchExp: "Preferred", extracurriculars: "Research, leadership", essays: "Critical", legacy: "Some impact", tags: ["🌵 Texas", "🎓 Intimate"] },
  { rank: 19, name: "Virginia Tech", location: "Blacksburg, VA", acceptRate: "66%", satRange: "1210–1430", gpaAvg: "3.80", apCourses: "3+", researchExp: "Helpful", extracurriculars: "STEM clubs, sports", essays: "Moderate", legacy: "Low impact", tags: ["🏫 Public", "⚙️ Applied"] },
  { rank: 20, name: "Penn State", location: "University Park, PA", acceptRate: "54%", satRange: "1180–1400", gpaAvg: "3.60", apCourses: "3+", researchExp: "Helpful", extracurriculars: "Clubs, co-ops", essays: "Moderate", legacy: "Low impact", tags: ["🏈 Spirit", "🏫 Public"] },
];

export default function Home() {
  const [messages, setMessages] = useState([
    {
      role: "assistant",
      content: "👋 Welcome to the **Engineering College Admission Advisor**! I can help you:\n\n• 📊 **Browse admission criteria** for top 20 US engineering schools\n• 🗺️ **Build your personalized 4-year roadmap** as a high school freshman\n• 💡 **Get strategic advice** on courses, tests, and extracurriculars\n\nWhat would you like to explore today?",
    },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState("chat");
  const [filterTag, setFilterTag] = useState("All");
  const [expandedCollege, setExpandedCollege] = useState(null);
  const messagesEndRef = useRef(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const allTags = ["All", ...new Set(COLLEGES.flatMap((c) => c.tags.map((t) => t.split(" ").slice(1).join(" "))))];
  const filteredColleges = filterTag === "All" ? COLLEGES : COLLEGES.filter((c) => c.tags.some((t) => t.includes(filterTag)));

  const sendMessage = async (text) => {
    const userMsg = text || input.trim();
    if (!userMsg) return;
    setInput("");
    const newMessages = [...messages, { role: "user", content: userMsg }];
    setMessages(newMessages);
    setLoading(true);

    try {
      const apiMessages = newMessages.map((m) => ({ role: m.role, content: m.content }));
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: apiMessages }),
      });
      const data = await res.json();
      if (data.error) {
        setMessages((prev) => [...prev, { role: "assistant", content: `⚠️ Error: ${data.error}` }]);
      } else {
        setMessages((prev) => [...prev, { role: "assistant", content: data.reply }]);
      }
    } catch (e) {
      setMessages((prev) => [...prev, { role: "assistant", content: "⚠️ Network error. Please try again." }]);
    }
    setLoading(false);
  };

  const quickPrompts = [
    "Build my 4-year roadmap for MIT",
    "Compare Stanford vs Caltech admissions",
    "What competitions should I do for top schools?",
    "How important is research experience?",
    "What APs should I take for CS engineering?",
    "Create a roadmap for a freshman interested in Mechanical Engineering",
  ];

  const renderMarkdown = (text) =>
    text
      .replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>")
      .replace(/\*(.*?)\*/g, "<em>$1</em>")
      .replace(/^• (.*)/gm, "<li>$1</li>")
      .replace(/^(\d+)\. (.*)/gm, "<li>$2</li>")
      .replace(/\n\n/g, "</p><p>")
      .replace(/^# (.*)/gm, "<h3>$1</h3>")
      .replace(/^## (.*)/gm, "<h4>$1</h4>")
      .replace(/\n/g, "<br/>");

  return (
    <>
      <Head>
        <title>Engineering Admissions Advisor</title>
        <meta name="description" content="AI-powered college admissions advisor for top US engineering programs" />
      </Head>

      <div style={{ fontFamily: "'DM Sans', 'Segoe UI', sans-serif", minHeight: "100vh", color: "#e8edf5", display: "flex", flexDirection: "column" }}>
        {/* Header */}
        <div style={{ padding: "20px 24px 0", background: "rgba(0,0,0,0.2)", borderBottom: "1px solid rgba(255,255,255,0.06)" }}>
          <div style={{ maxWidth: 1100, margin: "0 auto" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 16 }}>
              <div style={{ width: 40, height: 40, background: "linear-gradient(135deg, #1a6cf5, #0a3d9e)", borderRadius: 10, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 20 }}>🎓</div>
              <div>
                <div style={{ fontFamily: "'Space Grotesk', sans-serif", fontSize: 20, fontWeight: 700, color: "#fff", letterSpacing: "-0.5px" }}>Engineering Admissions Advisor</div>
                <div style={{ fontSize: 12, color: "#6888bb", marginTop: 1 }}>AI-powered guidance for top 20 US engineering programs</div>
              </div>
            </div>
            <div style={{ display: "flex", gap: 6 }}>
              {["chat", "colleges", "roadmap"].map((tab) => (
                <button key={tab} className={`tab-btn ${activeTab === tab ? "active" : ""}`} onClick={() => setActiveTab(tab)}
                  style={{ padding: "8px 18px", border: "none", borderRadius: "8px 8px 0 0", fontSize: 13, fontWeight: 600, cursor: "pointer", textTransform: "capitalize", background: "transparent" }}>
                  {tab === "chat" ? "💬 Chat" : tab === "colleges" ? "🏛️ Schools" : "🗺️ Roadmap"}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Main */}
        <div style={{ flex: 1, maxWidth: 1100, margin: "0 auto", width: "100%", padding: "0 24px 24px" }}>

          {/* CHAT TAB */}
          {activeTab === "chat" && (
            <div style={{ display: "flex", flexDirection: "column", paddingTop: 20, height: "calc(100vh - 140px)" }}>
              <div style={{ flex: 1, overflowY: "auto", display: "flex", flexDirection: "column", gap: 14, paddingRight: 4 }}>
                {messages.map((m, i) => (
                  <div key={i} className="msg-bubble" style={{ display: "flex", justifyContent: m.role === "user" ? "flex-end" : "flex-start" }}>
                    {m.role === "assistant" && (
                      <div style={{ width: 28, height: 28, background: "linear-gradient(135deg,#1a6cf5,#0a3d9e)", borderRadius: 8, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 14, flexShrink: 0, marginRight: 8, marginTop: 2 }}>🎓</div>
                    )}
                    <div style={{
                      maxWidth: "78%", padding: "12px 16px",
                      borderRadius: m.role === "user" ? "16px 4px 16px 16px" : "4px 16px 16px 16px",
                      background: m.role === "user" ? "linear-gradient(135deg,#1a6cf5,#0d4fc2)" : "rgba(255,255,255,0.05)",
                      border: m.role === "user" ? "none" : "1px solid rgba(255,255,255,0.08)",
                      fontSize: 14, lineHeight: 1.6, color: m.role === "user" ? "#fff" : "#d0ddf5",
                    }}>
                      <div dangerouslySetInnerHTML={{ __html: renderMarkdown(m.content) }} />
                    </div>
                  </div>
                ))}
                {loading && (
                  <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                    <div style={{ width: 28, height: 28, background: "linear-gradient(135deg,#1a6cf5,#0a3d9e)", borderRadius: 8, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 14 }}>🎓</div>
                    <div style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: "4px 16px 16px 16px", padding: "12px 18px", display: "flex", gap: 5 }}>
                      {[0, 1, 2].map((i) => <div key={i} className="typing-dot" style={{ width: 7, height: 7, background: "#4a7fd4", borderRadius: "50%" }} />)}
                    </div>
                  </div>
                )}
                <div ref={messagesEndRef} />
              </div>

              <div style={{ marginTop: 12, marginBottom: 10 }}>
                <div style={{ fontSize: 11, color: "#4a6a99", fontWeight: 600, marginBottom: 8, letterSpacing: "0.5px", textTransform: "uppercase" }}>Quick Start</div>
                <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
                  {quickPrompts.map((p, i) => (
                    <button key={i} className="quick-btn" onClick={() => sendMessage(p)} disabled={loading}
                      style={{ padding: "6px 12px", background: "rgba(26,108,245,0.08)", border: "1px solid rgba(26,108,245,0.25)", borderRadius: 20, fontSize: 12, color: "#8aaddf", cursor: "pointer" }}>
                      {p}
                    </button>
                  ))}
                </div>
              </div>

              <div style={{ display: "flex", gap: 10, background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 14, padding: "10px 14px", alignItems: "flex-end" }}>
                <textarea value={input} onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); } }}
                  placeholder="Ask about admissions, roadmap, strategies..." disabled={loading}
                  style={{ flex: 1, background: "transparent", border: "none", color: "#e0eaff", fontSize: 14, resize: "none", lineHeight: 1.5, maxHeight: 100, minHeight: 36, fontFamily: "inherit" }} rows={1} />
                <button className="send-btn" onClick={() => sendMessage()} disabled={loading || !input.trim()}
                  style={{ width: 38, height: 38, background: "linear-gradient(135deg,#1a6cf5,#0d4fc2)", border: "none", borderRadius: 10, cursor: "pointer", fontSize: 18, flexShrink: 0, color: "#fff" }}>
                  ↑
                </button>
              </div>
            </div>
          )}

          {/* COLLEGES TAB */}
          {activeTab === "colleges" && (
            <div style={{ paddingTop: 20 }}>
              <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 16 }}>
                {allTags.map((tag) => (
                  <button key={tag} className={`filter-chip ${filterTag === tag ? "active" : ""}`} onClick={() => setFilterTag(tag)}
                    style={{ padding: "5px 12px", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 20, fontSize: 12, fontWeight: 500, cursor: "pointer", background: "transparent", color: "#8899bb" }}>
                    {tag}
                  </button>
                ))}
              </div>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(320px, 1fr))", gap: 12, maxHeight: "75vh", overflowY: "auto" }}>
                {filteredColleges.map((c) => (
                  <div key={c.rank} className={`college-card ${expandedCollege === c.rank ? "expanded" : ""}`}
                    onClick={() => setExpandedCollege(expandedCollege === c.rank ? null : c.rank)}
                    style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 14, padding: 16 }}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 10 }}>
                      <div>
                        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                          <span style={{ width: 22, height: 22, background: "#1a6cf5", borderRadius: 6, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11, fontWeight: 700, color: "#fff", flexShrink: 0 }}>#{c.rank}</span>
                          <span style={{ fontFamily: "'Space Grotesk', sans-serif", fontSize: 16, fontWeight: 700, color: "#fff" }}>{c.name}</span>
                        </div>
                        <div style={{ fontSize: 12, color: "#6888bb", marginTop: 4, marginLeft: 30 }}>📍 {c.location}</div>
                      </div>
                      <span style={{ padding: "2px 8px", background: parseInt(c.acceptRate) < 10 ? "rgba(239,68,68,0.15)" : parseInt(c.acceptRate) < 20 ? "rgba(245,158,11,0.15)" : "rgba(34,197,94,0.15)", color: parseInt(c.acceptRate) < 10 ? "#f87171" : parseInt(c.acceptRate) < 20 ? "#fbbf24" : "#4ade80", borderRadius: 8, fontSize: 12, fontWeight: 700 }}>
                        {c.acceptRate}
                      </span>
                    </div>
                    <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: expandedCollege === c.rank ? 12 : 0 }}>
                      {c.tags.map((t) => <span key={t} style={{ fontSize: 11, padding: "2px 8px", background: "rgba(26,108,245,0.12)", color: "#6aabef", borderRadius: 20, border: "1px solid rgba(26,108,245,0.2)" }}>{t}</span>)}
                    </div>
                    {expandedCollege === c.rank && (
                      <div style={{ borderTop: "1px solid rgba(255,255,255,0.07)", paddingTop: 12 }}>
                        {[["📊 SAT Range", c.satRange], ["📚 Avg GPA", c.gpaAvg], ["🏫 AP Courses", c.apCourses], ["🔬 Research", c.researchExp], ["🎯 Essays", c.essays], ["👨‍👩‍👧 Legacy", c.legacy], ["🏆 Extracurriculars", c.extracurriculars]].map(([k, v]) => (
                          <div key={k} className="stat-row">
                            <span style={{ fontSize: 12, color: "#6888bb", fontWeight: 500 }}>{k}</span>
                            <span style={{ fontSize: 12, color: "#c8daf5", fontWeight: 600, textAlign: "right", maxWidth: "60%" }}>{v}</span>
                          </div>
                        ))}
                        <button onClick={(e) => { e.stopPropagation(); setActiveTab("chat"); sendMessage(`Tell me about ${c.name}'s engineering admission requirements and tips to get in`); }}
                          style={{ marginTop: 10, width: "100%", padding: "8px", background: "linear-gradient(135deg,#1a6cf5,#0d4fc2)", border: "none", borderRadius: 8, color: "#fff", fontSize: 12, fontWeight: 600, cursor: "pointer" }}>
                          Ask AI about {c.name} →
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ROADMAP TAB */}
          {activeTab === "roadmap" && (
            <div style={{ paddingTop: 20 }}>
              <div style={{ background: "rgba(26,108,245,0.08)", border: "1px solid rgba(26,108,245,0.2)", borderRadius: 14, padding: 20, marginBottom: 20 }}>
                <div style={{ fontFamily: "'Space Grotesk', sans-serif", fontSize: 16, fontWeight: 700, marginBottom: 6 }}>🗺️ Build Your Custom 4-Year Roadmap</div>
                <div style={{ fontSize: 13, color: "#8aaddf", lineHeight: 1.6 }}>Tell me your interests and target schools in the chat, and I&apos;ll create a personalized plan for your engineering admission journey.</div>
                <button onClick={() => { setActiveTab("chat"); sendMessage("I'm a high school freshman interested in engineering. Can you build me a detailed 4-year roadmap to get into a top 10 engineering school? I like computer science and math."); }}
                  style={{ marginTop: 12, padding: "9px 20px", background: "linear-gradient(135deg,#1a6cf5,#0d4fc2)", border: "none", borderRadius: 10, color: "#fff", fontSize: 13, fontWeight: 600, cursor: "pointer" }}>
                  Generate My Roadmap →
                </button>
              </div>
              {[
                { year: "9th Grade", color: "#22c55e", icon: "🌱", items: ["Enroll in Algebra II or Pre-Calculus", "Join robotics or science club", "Start learning Python/JavaScript", "Aim for all A's — GPA starts now", "Explore AP CS Principles", "Attend FIRST robotics or math team"] },
                { year: "10th Grade", color: "#3b82f6", icon: "📈", items: ["Take AP Calculus AB or BC", "Start AMC 10/AMC 8 competitions", "Science fair project — local/regional", "Learn data structures, build projects", "Shadow an engineer or researcher", "SAT prep — aim 1350+ baseline"] },
                { year: "11th Grade", color: "#f59e0b", icon: "🚀", items: ["Take 3-4 APs (Physics C, CS A, Chem)", "SAT/ACT — target 1450+ for top 20", "Research internship or university program", "AMC 10/12, Science Olympiad", "Build a meaningful project", "Start college list (reach/match/safety)"] },
                { year: "12th Grade", color: "#ef4444", icon: "🎓", items: ["Apply Early Decision/Action (Nov 1-15)", "Finalize essays — start in August", "Request rec letters by September", "Maintain senior year leadership", "Submit Common App + supplements", "Apply for scholarships & FAFSA"] },
              ].map((phase, i) => (
                <div key={i} style={{ display: "flex", gap: 16, marginBottom: 16 }}>
                  <div style={{ display: "flex", flexDirection: "column", alignItems: "center", flexShrink: 0 }}>
                    <div style={{ width: 40, height: 40, background: phase.color + "22", border: `2px solid ${phase.color}`, borderRadius: 12, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18 }}>{phase.icon}</div>
                    {i < 3 && <div style={{ width: 2, flex: 1, background: "rgba(255,255,255,0.07)", marginTop: 4 }} />}
                  </div>
                  <div style={{ flex: 1, background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 12, padding: "14px 16px", marginBottom: 4 }}>
                    <div style={{ fontFamily: "'Space Grotesk', sans-serif", fontWeight: 700, fontSize: 15, color: phase.color, marginBottom: 10 }}>{phase.year}</div>
                    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "6px 12px" }}>
                      {phase.items.map((item, j) => (
                        <div key={j} style={{ display: "flex", alignItems: "flex-start", gap: 6, fontSize: 12, color: "#a0b8d8", lineHeight: 1.5 }}>
                          <span style={{ color: phase.color, marginTop: 2, flexShrink: 0 }}>▸</span>{item}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </>
  );
}
